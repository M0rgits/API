# Sleeping Beauty

![Screenshot](sleeping-beauty.png)

This is a [7DRL](http://7drl.org/) game. To play it, just open https://ondras.github.io/sleeping-beauty/ in your browser.

## Technology

HTML, CSS (LESS), JavaScript (ES2015).

  - Building:
```
$ npm install
$ npm run build
```

The font used is [Metrickal](https://github.com/robey/metrickal-typeface).
