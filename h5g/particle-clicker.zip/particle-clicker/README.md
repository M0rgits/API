# Particle Clicker

An addictive incremental game that teaches players the history of high energy particle physics.

Developed during the 2014 CERN Webfest over a weekend.

Visit [http://cern.ch/particle-clicker](http://cern.ch/particle-clicker) to play the game.
