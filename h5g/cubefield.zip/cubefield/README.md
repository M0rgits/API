# cubefield
Cubefield clone using Three.JS

Live at [christopher-hayes.github.io/cubefield](https://christopher-hayes.github.io/cubefield)
