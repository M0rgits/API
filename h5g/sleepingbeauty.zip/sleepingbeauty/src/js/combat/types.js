export const ATTACK_1 = "a1";
export const ATTACK_2 = "a2";
export const MAGIC_1 = "m1";
export const MAGIC_2 = "m2";

export const COLORS = {
	[ATTACK_1]: "#0f0",
	[ATTACK_2]: "#f00",
	[MAGIC_1]: "#00f",
	[MAGIC_2]: "#ff3"
}
